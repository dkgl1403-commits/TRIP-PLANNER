import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, useMap, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';

// Fix Leaflet's default icon path issues
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

// Helper to generate consistent colors for participants based on ID or Name
const stringToColor = (str) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  let color = '#';
  for (let i = 0; i < 3; i++) {
    const value = (hash >> (i * 8)) & 0xFF;
    // Keep it vivid but not pure white/black
    let adjusted = Math.max(50, Math.min(220, value));
    color += ('00' + adjusted.toString(16)).substr(-2);
  }
  return color;
};

// Generate CSS Arrow icon for Participants
const getParticipantIcon = (color) => {
  return L.divIcon({
    className: 'participant-marker',
    html: `<div style="width: 0; height: 0; border-left: 10px solid transparent; border-right: 10px solid transparent; border-bottom: 24px solid ${color}; filter: drop-shadow(0px 3px 3px rgba(0,0,0,0.4));"></div>`,
    iconSize: [20, 24],
    iconAnchor: [10, 12]
  });
};

function RoutingMachine({ source, destination, checkpoints, enableNavigation }) {
  const map = useMap();
  const routingControlRef = useRef(null);

  useEffect(() => {
    if (!map) return;

    const waypoints = [];
    if (source && source.lat && source.lon) {
      waypoints.push(L.latLng(source.lat, source.lon));
    }
    
    if (checkpoints && checkpoints.length > 0) {
      checkpoints.forEach(cp => {
        if (cp.lat && cp.lon) {
          waypoints.push(L.latLng(cp.lat, cp.lon));
        }
      });
    }

    if (destination && destination.lat && destination.lon) {
      waypoints.push(L.latLng(destination.lat, destination.lon));
    }

    if (waypoints.length > 0) {
      if (routingControlRef.current) {
        routingControlRef.current.getPlan().setWaypoints(waypoints);
        // We always keep the text itinerary hidden as requested
      } else {
        routingControlRef.current = L.Routing.control({
          waypoints: waypoints,
          lineOptions: {
            styles: [{ color: '#1e3a8a', opacity: 0.8, weight: 6 }] // Dark blue route line
          },
          show: false, // Permanently hide the text itinerary
          routeWhileDragging: false,
          addWaypoints: false,
          fitSelectedRoutes: true,
          showAlternatives: true
        }).addTo(map);
      }
    } else {
      if (routingControlRef.current) {
        routingControlRef.current.getPlan().setWaypoints([]);
      }
    }

  }, [map, source, destination, checkpoints, enableNavigation]);

  return null;
}

function NavigationController({ isNavigating }) {
  const map = useMap();
  const [navMarker, setNavMarker] = React.useState(null);

  useEffect(() => {
    let watchId;
    if (isNavigating && "geolocation" in navigator) {
      let marker = navMarker;
      
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const latlng = [latitude, longitude];
          const heading = position.coords.heading || 0;
          
          const iconHtml = `<div style="width: 0; height: 0; border-left: 14px solid transparent; border-right: 14px solid transparent; border-bottom: 34px solid #3b82f6; filter: drop-shadow(0px 4px 6px rgba(0,0,0,0.6)); transform: rotate(${heading}deg); transform-origin: 50% 60%;"></div>`;
          const icon = L.divIcon({
            className: 'nav-marker',
            html: iconHtml,
            iconSize: [28, 34],
            iconAnchor: [14, 20]
          });
          
          if (!marker) {
            marker = L.marker(latlng, { icon }).addTo(map);
            setNavMarker(marker);
          } else {
            marker.setLatLng(latlng);
            marker.setIcon(icon); // Update icon to reflect heading change
          }
          
          // Center and zoom in to simulate navigation perspective
          map.setView(latlng, 17, { animate: true, duration: 1 });
        },
        (error) => console.error("Navigation geolocation error: ", error),
        { enableHighAccuracy: true, maximumAge: 0 }
      );
    } else {
      if (navMarker) {
        map.removeLayer(navMarker);
        setNavMarker(null);
      }
    }

    return () => {
      if (watchId !== undefined) navigator.geolocation.clearWatch(watchId);
    };
  }, [isNavigating, map]);

  return null;
}

function ResizeController({ isFullscreen }) {
  const map = useMap();
  useEffect(() => {
    // Wait a short tick for CSS transitions/render before invalidating size
    setTimeout(() => {
      map.invalidateSize();
    }, 100);
  }, [isFullscreen, map]);
  return null;
}

export default function TripMap({ source, destination, checkpoints = [], liveLocations = [], enableNavigation = false, isNavigating = false, isFullscreen = false }) {
  return (
    <MapContainer 
      center={[20.5937, 78.9629]} // Default to India
      zoom={5} 
      style={{ height: '100%', width: '100%', borderRadius: '15px' }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <RoutingMachine 
        source={source} 
        destination={destination} 
        checkpoints={checkpoints} 
        enableNavigation={enableNavigation}
      />
      <NavigationController isNavigating={isNavigating} />

      {/* Trigger map resize on fullscreen toggle */}
      <ResizeController isFullscreen={isFullscreen} />

      {/* Render live participant locations as colored arrows */}
      {liveLocations.map((loc, idx) => {
        const participantColor = stringToColor(loc.login_id || loc.name);
        return (
          <Marker key={idx} position={[loc.lat, loc.lon]} icon={getParticipantIcon(participantColor)}>
            <Popup>
              <strong>{loc.name}</strong><br/>
              Updated: {new Date(loc.last_updated).toLocaleTimeString()}
            </Popup>
          </Marker>
        );
      })}
    </MapContainer>
  );
}
